<h1 align="center">The Gorgeous Login</h1>

<h3 align="center">
  A login page built with flutter inspired by a design found on Uplabs
</h3>

Uplabs design        |  Flutter rendering
:-------------------------:|:-------------------------:
![original-design](./github/template.jpg)  |   ![](./github/login.gif)
